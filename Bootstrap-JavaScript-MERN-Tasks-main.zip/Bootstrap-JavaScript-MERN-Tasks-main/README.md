# Bootstrap-JavaScript-MERN-Taskss
# Info
1) Name: ADITH SAGAR GOWDA
2) Reg No: 21BAI1928
3) VIT Email: adithsagar.gowda2021@vitstudent.ac.in
4) Personal Email: adithgowda06@gmail.com

# Details
This repository includes all the tasks/works done during the course of the MERN-Stack.

Consists of - 
1) 6 Bootstrap tasks
2) 8 JavaScript tasks
